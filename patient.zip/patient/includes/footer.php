<footer style="position: relative; bottom: 10px; text-align:center; margin-top: 40px;">
    Copyright <?php echo date("Y"); ?> Department of Computer Science HUKPOLY.
</footer>