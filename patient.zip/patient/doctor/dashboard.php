<?php

echo "Doctor's Dashboard";

?>